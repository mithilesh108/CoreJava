create user 'fithealthappuser'@'%' identified by 'welcome1';
grant all privileges on *.* to 'fithealthappuser'@'%';
flush privileges;